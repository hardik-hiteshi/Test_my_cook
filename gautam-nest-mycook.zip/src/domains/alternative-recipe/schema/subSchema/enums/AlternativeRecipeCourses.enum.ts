const alternativeRecipeCourses = [
  '',
  'first',
  'second',
  'dessert',
  'breakfast',
  'appetizer',
  'snack',
];
export default alternativeRecipeCourses;
