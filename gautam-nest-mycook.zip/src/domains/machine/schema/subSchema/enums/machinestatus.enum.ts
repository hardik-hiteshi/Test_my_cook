const machinestatus = ['enabled', 'disabled', 'lost+found'];
export default machinestatus;
