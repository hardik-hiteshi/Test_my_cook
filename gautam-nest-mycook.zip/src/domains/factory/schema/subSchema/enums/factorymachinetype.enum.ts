const factorymachinetypes = ['Mycook Touch', 'iCookin'];
export default factorymachinetypes;
