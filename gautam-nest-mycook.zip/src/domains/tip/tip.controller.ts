import { Controller } from '@nestjs/common';

@Controller('tip')
export class TipController {}
