const machineClodVersions = ['S1', 'S1.1', 'S2'];
export default machineClodVersions;
