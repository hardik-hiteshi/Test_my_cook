import { Controller } from '@nestjs/common';

@Controller('machineModel')
export class MachineModelController {}
