export enum Role {
  user = 'user',
  admin = 'admin',
}
