import { IsEnum, IsNumber, IsOptional, IsString } from 'class-validator';
import iUscaleEnum from 'src/domains/recipe/schema/subSchema/enums/nutritionalKeysEnum/IUScale.enum';
export class IUscaleDTO {
  @IsOptional()
  @IsNumber()
  public value: number;
  @IsOptional()
  @IsString()
  @IsEnum(iUscaleEnum)
  public unit: string;
}
