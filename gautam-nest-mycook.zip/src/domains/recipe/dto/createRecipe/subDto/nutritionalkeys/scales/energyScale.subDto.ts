import { IsEnum, IsNumber, IsOptional, IsString } from 'class-validator';
import energyScaleEnum from 'src/domains/recipe/schema/subSchema/enums/nutritionalKeysEnum/EnergyScale.enum';
export class EnergyScaleDTO {
  @IsOptional()
  @IsNumber()
  public value: number;
  @IsOptional()
  @IsString()
  @IsEnum(energyScaleEnum)
  public unit: string;
}
