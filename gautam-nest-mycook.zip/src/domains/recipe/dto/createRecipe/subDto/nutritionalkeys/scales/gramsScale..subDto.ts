import { IsEnum, IsNumber, IsOptional, IsString } from 'class-validator';
import gramScaleEnum from 'src/domains/recipe/schema/subSchema/enums/nutritionalKeysEnum/gramScale.enum';

export class GramsScaleDTO {
  @IsOptional()
  @IsNumber()
  public value: number;
  @IsOptional()
  @IsString()
  @IsEnum(gramScaleEnum)
  public unit: string;
}
