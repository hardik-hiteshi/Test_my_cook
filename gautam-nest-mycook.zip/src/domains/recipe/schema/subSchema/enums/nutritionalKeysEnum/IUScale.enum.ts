const iUscaleEnum = ['IU'];
export default iUscaleEnum;
