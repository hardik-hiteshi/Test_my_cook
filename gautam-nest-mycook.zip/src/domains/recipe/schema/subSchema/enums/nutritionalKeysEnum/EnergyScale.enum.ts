const energyScaleEnum = ['Kcal'];
export default energyScaleEnum;
