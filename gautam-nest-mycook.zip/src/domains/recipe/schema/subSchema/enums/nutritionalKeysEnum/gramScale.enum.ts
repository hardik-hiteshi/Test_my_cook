const gramScaleEnum = ['g', 'mg', 'ug'];
export default gramScaleEnum;
