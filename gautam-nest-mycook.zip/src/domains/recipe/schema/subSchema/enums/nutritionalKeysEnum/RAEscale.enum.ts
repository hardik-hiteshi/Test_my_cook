const rAEscaleEnum = ['RAE'];
export default rAEscaleEnum;
