const stepType = [
  'mycook',
  'bake',
  'fry',
  'coat',
  'manipulation',
  'repose',
  'stew',
  'microwave',
];
export default stepType;
