const stepFunction = [
  'normal',
  'saute',
  'knead',
  'turbo',
  'progressive',
  'slow-cook',
  'sous-vide',
  'high-temperature',
  'steam',
  'kettle',
];
export default stepFunction;
