const nutritionalEnum = ['Auto (Good)', 'Auto (Bad)', 'Manual', ''];
export default nutritionalEnum;
