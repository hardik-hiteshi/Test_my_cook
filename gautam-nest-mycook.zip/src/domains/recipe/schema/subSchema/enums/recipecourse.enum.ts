const recipecourses = [
  '',
  'Breakfast',
  'Morning snack',
  'Afternoon snack',
  'Lunch starter',
  'Lunch main',
  'Lunch desert',
  'Diner starter',
  'Diner main',
  'Diner desert',
];
export default recipecourses;
