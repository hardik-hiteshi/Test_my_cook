const difficultyEnum = [1, 2, 3];
export default difficultyEnum;
