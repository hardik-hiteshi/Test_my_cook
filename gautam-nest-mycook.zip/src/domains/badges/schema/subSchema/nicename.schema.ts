import { Schema } from '@nestjs/mongoose';
@Schema()
export class NICENAME {}
