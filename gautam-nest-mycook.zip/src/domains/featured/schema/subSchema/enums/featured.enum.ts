const featureduser = ['User', 'Recipe'];
export default featureduser;
