//this class is empty because the values are readonly.
export class ToDTO {}
