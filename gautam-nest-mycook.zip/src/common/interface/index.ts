export * from './recursivePartial/recursivePartial.interface';
